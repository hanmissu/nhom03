<?php
define('SERVERNAME', 'localhost');
define('USERNAME', 'root');
define('PASSWORD', '');
define('DB', 'do_an');
define('ROOT', __DIR__);//thu muc tro toi config
?>
